package com.bean;

public class ShopCar {
	private String name;
	private String maker;
	public String getname() {
		return name;
	}
	public void setname(String name) {
		this.name = name;
	}
	public String getmaker() {
		return maker;
	}
	public void setmaker(String maker) {
		this.maker = maker;
	}
	public ShopCar() {
		name = "noname";
		maker = "noplace";
	}
}
