package xianggu;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javafx.util.Pair;

public class Ganshijian {
	static public HashMap<Integer, DRProducer> map;
	static {
		map = new HashMap();
		map.put(1, new DRProducer(1, 150, new Date(2019, 4, 24)));
		map.put(2, new DRProducer(2, 250, new Date(2019, 4, 25)));
	}
	public static Map<Integer, DRProducer> getm() {
		return map;
	}
}
