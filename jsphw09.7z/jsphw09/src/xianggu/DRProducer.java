package xianggu;
import java.util.Date;

public class DRProducer {
	public int pid, plv;
	public Date ptime;
	public DRProducer(int pid, int plv, Date ptime) {
		super();
		this.pid = pid;
		this.plv = plv;
		this.ptime = ptime;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public int getPlv() {
		return plv;
	}
	public void setPlv(int plv) {
		this.plv = plv;
	}
	public Date getPtime() {
		return ptime;
	}
	public void setPtime(Date ptime) {
		this.ptime = ptime;
	}
}
