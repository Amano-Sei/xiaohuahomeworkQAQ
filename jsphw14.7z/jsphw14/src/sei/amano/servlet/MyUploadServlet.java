package sei.amano.servlet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadBase.FileSizeLimitExceededException;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

//��ȡ�ϴεĽ�ѵ...��β���eclipse�Լ����servlet-mapping��...
//��˵���������ע�⻹û�п�Ŷ

public class MyUploadServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		String message = "����������";
		if(ServletFileUpload.isMultipartContent(request)) {
			String papath = request.getServletContext().getRealPath("/toupload");
			File pf = new File(papath);
			if(!pf.exists())
				pf.mkdirs();
			DiskFileItemFactory dfif = new DiskFileItemFactory(2*1024*1024, pf);
			ServletFileUpload upload = new ServletFileUpload(dfif);
			upload.setFileSizeMax(2*1024*1024);
				List<FileItem> items;
				try {
					items = upload.parseRequest(request);
					Iterator<FileItem> it = items.iterator();
					while(it.hasNext()) {
						FileItem cfi = it.next();
						if(!cfi.isFormField()) {
							InputStream is = cfi.getInputStream();
							System.out.println(cfi.getName());
							String name = new String(cfi.getName().getBytes(StandardCharsets.ISO_8859_1), StandardCharsets.UTF_8);
							System.out.println(name);
							FileOutputStream fw = new FileOutputStream(new File(papath+File.separator+name));
							byte[] buf = new byte[512];
							int length;
							while((length = is.read(buf))!=-1)
								fw.write(buf, 0, length);
							message = name+"�ϴ��ɹ�";
							break;
						}
					}
				} catch (FileSizeLimitExceededException e) {
					// TODO Auto-generated catch block
					message = "�ļ�����";
					e.printStackTrace();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					message = "failed...";
					e.printStackTrace();
				}
		}
		//System.out.println(request.getServletContext().getContextPath());
		request.setAttribute("message", message);
		//response.sendRedirect(request.getServletContext().getContextPath()+"/toup.jsp?message="+message);
		request.getRequestDispatcher("/toup.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doGet(req, resp);
	}

}
